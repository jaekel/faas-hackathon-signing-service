/* eslint-disable */
// prettier-ignore
exports.handler = async function (event, context) {
    return { "foo": 42 };
};
/* eslint-disable */
